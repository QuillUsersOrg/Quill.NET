﻿UPDATE emp SET ename = '日本語'
WHERE empno = /*employee.Empno*/7788